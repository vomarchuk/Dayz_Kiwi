#ifndef RANDOM_ITEMS_LIST
#define RANDOM_ITEMS_LIST

class RandomItemsList
{
    static ref array<string> GetItems()
    {
        // список рандомних нагород
        return {  
            "Blowtorch",
            "TD_GRN2014_money20",
            "TD_GRN2014_money50",
            "CP_CannabisSeedsPackBlackFrost",
            "CP_CannabisSeedsPackFuture",
            "CP_CannabisSeedsPackNomad",
            "CP_EmptyBag",
            "CP_TobaccoSeedsPack",
            "ElectronicRepairKit",
            "FieldShovel",
            "GP5GasMask",
            "GPSReceiver",
            "GardenLime",
            "Hammer",
            "Hacksaw",
            "HP_napilnik",
            "Jig",
            "HuntingKnife",
            "LargeGasCanister",
            "M67Grenade",
            "MediumGasCanister",
            "NBCBootsGray",
            "NBCPantsGray",
            "NBCJacketGray",
            "NBCHoodGray",
            "NBCGlovesGray",
            "NailBox",
            "NailBox",
            "Pipewrench",
            "PortableGasStove",
            "RDG5Grenade",
            "RIP_Glue",
            "RIP_OilPlastic",
            "RIP_WD40S",
            "RIP_WeaponCleaningSpray_2",
            "Screwdriver",
            "SmallGasCanister",
            "SmallProtectorCase",
            "TacticalBaconCan",
            "TerjeAmpouleFlemoclav",
            "TerjeAmpouleZivirol",
            "TerjeDrink6Energy",
            "TerjeDrinkYaguar",
            "TerjeInjectorNeirox",
            "TerjePillsAmoxiclav",
            "TerjePillsPiperacylin",
            "TerjeSurgicalKit",
            "TerjeSyringeNew",
            "WeaponCleaningKit",
            "TD_GRN2014_money20",
            "TD_GRN2014_money50",
            "CharcoalTablets"
        };
    }
}
#endif